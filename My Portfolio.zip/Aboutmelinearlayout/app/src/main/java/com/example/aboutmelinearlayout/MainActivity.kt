package com.example.aboutmelinearlayout

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.graphics.Bitmap
import android.webkit.WebViewClient

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    private lateinit var myWebView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        myWebView = findViewById(R.id.webview)
        myWebView.webViewClient = MyWebClient()
        myWebView.loadUrl("https://careerservices.fas.harvard.edu/blog/2023/01/10/23-resume-tips-for-2023/")

        val webSettings = myWebView.settings
        webSettings.javaScriptEnabled = true
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (myWebView.canGoBack()) {
            myWebView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    private inner class MyWebClient : WebViewClient() {
        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
        }

        @Deprecated("Deprecated in Java")
        override fun shouldOverrideUrlLoading(view: WebView? , url: String?): Boolean {
            if (url != null) {
                view?.loadUrl(url)
            }
            return true
        }
    }
}

